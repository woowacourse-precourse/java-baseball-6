package baseball.view;

public class OutputView {
    public static void gameStartMessage() {
        System.out.println("숫자 야구 게임을 시작합니다.");
    }

    public static void enterPlayerNumMessage() {
        System.out.print("숫자를 입력해주세요 : ");
    }

}
