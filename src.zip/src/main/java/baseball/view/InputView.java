package baseball.view;

public class InputView {





}
